import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { ThumbnailCard } from './components/ThumbnailCard';
import { Modal } from './components/Modal';
import { LoadingSpinner, ZipIcon, LinkIcon } from './components/icons';
import { SeoContent } from './components/SeoContent';
import { extractVideoId } from './utils/youtube';
import { downloadFile, downloadAllAsZip } from './utils/download';
import type { Thumbnail, ModalContent, ThumbnailQuality } from './types';
import { THUMBNAIL_QUALITIES, MODAL_CONTENT } from './constants';

const App: React.FC = () => {
  const [youtubeUrl, setYoutubeUrl] = useState<string>('');
  const [thumbnails, setThumbnails] = useState<Thumbnail[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [modalContent, setModalContent] = useState<ModalContent | null>(null);

  const generateThumbnails = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!youtubeUrl.trim()) {
      setError('Please enter a valid YouTube link.');
      return;
    }

    setIsLoading(true);
    setError(null);
    setThumbnails([]);

    const videoId = extractVideoId(youtubeUrl);
    if (!videoId) {
      setError('Invalid link or video not available. Please check again.');
      setIsLoading(false);
      return;
    }

    const generatedThumbnails = THUMBNAIL_QUALITIES.map((quality: ThumbnailQuality) => ({
        quality: quality.label,
        resolution: quality.resolution,
        url: `https://i.ytimg.com/vi/${videoId}/${quality.id}.jpg`,
        fallbackUrl: quality.fallbackId ? `https://i.ytimg.com/vi/${videoId}/${quality.fallbackId}.jpg` : undefined,
    }));
    
    setThumbnails(generatedThumbnails);
    setIsLoading(false);
  }, [youtubeUrl]);
  
  const handleDownloadAll = async () => {
      if(thumbnails.length === 0) return;
      
      const videoId = extractVideoId(youtubeUrl);
      await downloadAllAsZip(thumbnails, videoId || 'thumbnails');
  };

  const openModal = (contentKey: 'privacy' | 'terms' | 'about') => {
    setModalContent(MODAL_CONTENT[contentKey]);
  };

  return (
    <div className="flex flex-col min-h-screen bg-white font-sans text-slate-800">
      <Header />
      <main className="flex-grow w-full max-w-4xl mx-auto px-4 py-8 md:py-16">
        <div className="text-center">
          <h1 className="text-3xl md:text-5xl font-bold mb-2 bg-gradient-to-r from-blue-600 to-slate-800 text-transparent bg-clip-text">
            Download YouTube Thumbnails Instantly
          </h1>
          <h2 className="text-md md:text-lg text-slate-600 mb-8">
            Get YouTube video thumbnails in HD, HQ, and MQ quality — completely free.
          </h2>
        </div>

        <form onSubmit={generateThumbnails} className="max-w-2xl mx-auto">
          <div className="flex flex-col sm:flex-row gap-2">
            <div className="relative flex-grow">
               <div className="absolute inset-y-0 left-0 flex items-center pl-4 pointer-events-none">
                <LinkIcon />
              </div>
              <input
                type="url"
                value={youtubeUrl}
                onChange={(e) => setYoutubeUrl(e.target.value)}
                placeholder="Paste your YouTube video link here"
                className="w-full pl-11 pr-4 py-3 text-base text-slate-700 bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
                aria-label="YouTube video link"
                required
              />
            </div>
            <button
              type="submit"
              disabled={isLoading}
              className="flex items-center justify-center bg-blue-600 text-white font-semibold py-3 px-6 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-blue-300 disabled:cursor-not-allowed transition-colors duration-300"
            >
              {isLoading ? <LoadingSpinner /> : 'Generate Thumbnails'}
            </button>
          </div>
          <p className="text-xs text-slate-500 mt-3 text-center">
            Only public videos supported. No login required.
          </p>
        </form>

        {error && (
          <div className="max-w-2xl mx-auto mt-6 p-3 text-center text-red-700 bg-red-100 border border-red-200 rounded-lg">
            {error}
          </div>
        )}
        
        {thumbnails.length > 0 && (
          <div className="mt-12 animate-fade-in">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {thumbnails.map((thumb) => (
                <ThumbnailCard 
                  key={thumb.quality} 
                  thumbnail={thumb} 
                  onDownload={() => downloadFile(thumb.fallbackUrl || thumb.url, `thumbnail-${thumb.quality.toLowerCase()}.jpg`)} 
                />
              ))}
            </div>
            <div className="text-center mt-8">
              <button 
                onClick={handleDownloadAll}
                className="inline-flex items-center justify-center gap-2 bg-green-600 text-white font-semibold py-3 px-8 rounded-lg hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition-colors duration-300"
              >
                <ZipIcon />
                Download All (ZIP)
              </button>
            </div>
          </div>
        )}
      </main>
      <SeoContent />
      <Footer onLinkClick={openModal} />
      {modalContent && (
        <Modal
          title={modalContent.title}
          onClose={() => setModalContent(null)}
        >
          {modalContent.content}
        </Modal>
      )}
    </div>
  );
};

export default App;