import React from 'react';

interface FooterProps {
  onLinkClick: (contentKey: 'privacy' | 'terms' | 'about') => void;
}

export const Footer: React.FC<FooterProps> = ({ onLinkClick }) => {
  return (
    <footer className="bg-slate-50 border-t border-slate-200">
      <div className="w-full max-w-4xl mx-auto px-4 py-6">
        <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="text-center sm:text-left">
            <p className="text-sm text-slate-500">
              © {new Date().getFullYear()} YTThumbs. All Rights Reserved.
            </p>
            <p className="text-xs text-slate-400 mt-1">
              A free tool to quickly download YouTube video thumbnails.
            </p>
          </div>
          <div className="flex gap-4 sm:gap-6">
            <button onClick={() => onLinkClick('privacy')} className="text-sm text-slate-600 hover:text-blue-600 transition-colors">
              Privacy Policy
            </button>
            <button onClick={() => onLinkClick('terms')} className="text-sm text-slate-600 hover:text-blue-600 transition-colors">
              Terms & Conditions
            </button>
            <button onClick={() => onLinkClick('about')} className="text-sm text-slate-600 hover:text-blue-600 transition-colors">
              About Us
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};