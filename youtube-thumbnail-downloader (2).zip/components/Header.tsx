import React from 'react';

export const Header: React.FC = () => {
  return (
    <header className="bg-white/80 backdrop-blur-md sticky top-0 z-10 border-b border-slate-200">
      <div className="w-full max-w-4xl mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          <div className="text-2xl font-bold text-slate-900 tracking-tight">
            YT<span className="text-blue-600">Thumbs</span>
          </div>
          <div className="hidden sm:block text-sm text-slate-600">
            Instant HD thumbnails
          </div>
        </div>
      </div>
    </header>
  );
};
