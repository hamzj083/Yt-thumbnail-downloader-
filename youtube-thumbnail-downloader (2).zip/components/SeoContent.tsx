import React from 'react';
import { FastIcon, QualityIcon, FreeIcon, SecureIcon } from './icons';

const HowItWorks: React.FC = () => (
  <div className="text-center">
    <h2 className="text-3xl font-bold text-slate-900">Get Your Thumbnail in 3 Simple Steps</h2>
    <p className="mt-2 max-w-2xl mx-auto text-lg text-slate-600">
      Downloading a YouTube thumbnail has never been easier.
    </p>
    <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8">
      <div className="flex flex-col items-center">
        <div className="flex items-center justify-center h-16 w-16 bg-blue-100 text-blue-600 rounded-full text-2xl font-bold">1</div>
        <h3 className="mt-4 text-xl font-semibold text-slate-800">Paste Link</h3>
        <p className="mt-2 text-slate-500">Copy the YouTube video URL and paste it into the input field above.</p>
      </div>
      <div className="flex flex-col items-center">
        <div className="flex items-center justify-center h-16 w-16 bg-blue-100 text-blue-600 rounded-full text-2xl font-bold">2</div>
        <h3 className="mt-4 text-xl font-semibold text-slate-800">Generate</h3>
        <p className="mt-2 text-slate-500">Click "Generate Thumbnails" to instantly see all available qualities.</p>
      </div>
      <div className="flex flex-col items-center">
        <div className="flex items-center justify-center h-16 w-16 bg-blue-100 text-blue-600 rounded-full text-2xl font-bold">3</div>
        <h3 className="mt-4 text-xl font-semibold text-slate-800">Download</h3>
        <p className="mt-2 text-slate-500">Click "Download" on your desired thumbnail, or get them all in a ZIP file.</p>
      </div>
    </div>
  </div>
);

const Features: React.FC = () => (
  <div className="text-center">
    <h2 className="text-3xl font-bold text-slate-900">Why Choose YTThumbs?</h2>
    <p className="mt-2 max-w-2xl mx-auto text-lg text-slate-600">
      We provide the best features to make your experience seamless.
    </p>
    <div className="mt-12 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8">
      <div className="flex flex-col items-center p-4">
        <QualityIcon />
        <h3 className="mt-4 text-xl font-semibold text-slate-800">High Quality</h3>
        <p className="mt-2 text-slate-500">Download thumbnails in the highest possible resolution (HD, SD, HQ).</p>
      </div>
      <div className="flex flex-col items-center p-4">
        <FreeIcon />
        <h3 className="mt-4 text-xl font-semibold text-slate-800">Completely Free</h3>
        <p className="mt-2 text-slate-500">No hidden costs, no subscriptions. Our tool is 100% free to use.</p>
      </div>
      <div className="flex flex-col items-center p-4">
        <FastIcon />
        <h3 className="mt-4 text-xl font-semibold text-slate-800">Fast & Instant</h3>
        <p className="mt-2 text-slate-500">Generate and download thumbnails in seconds. No waiting around.</p>
      </div>
       <div className="flex flex-col items-center p-4">
        <SecureIcon />
        <h3 className="mt-4 text-xl font-semibold text-slate-800">Safe & Secure</h3>
        <p className="mt-2 text-slate-500">All processing is done in your browser. We don't see or store your links.</p>
      </div>
    </div>
  </div>
);

const Faq: React.FC = () => {
    const faqs = [
        {
            q: "What is a YouTube thumbnail downloader?",
            a: "It's an online tool that allows you to easily grab and save the thumbnail image from any public YouTube video. You just need the video's URL to get high-quality images for your projects, archives, or inspiration."
        },
        {
            q: "Is it legal to download YouTube thumbnails?",
            a: "Thumbnails are copyrighted by the video's creator. Downloading them is generally acceptable for personal use, like for a school project or your own collection. However, for commercial use, you should always get permission from the copyright owner to avoid any legal issues."
        },
        {
            q: "What resolutions are available for download?",
            a: "This tool provides several qualities, including HD (1280x720), SD (640x480), and smaller resolutions. The highest quality available depends on what the original creator uploaded to YouTube."
        },
        {
            q: "Do I need to sign up or install any software?",
            a: "Absolutely not. Our tool is entirely web-based and free. You don't need an account, and there's nothing to install. Just paste the link and download."
        }
    ];

    return (
        <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl font-bold text-slate-900 text-center">Frequently Asked Questions</h2>
            <div className="mt-8 space-y-4">
                {faqs.map((faq, index) => (
                    <details key={index} className="group p-4 bg-white border rounded-lg cursor-pointer">
                        <summary className="flex justify-between items-center font-semibold text-slate-800 text-lg list-none">
                            {faq.q}
                            <span className="transition-transform transform group-open:rotate-180">
                                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
                            </span>
                        </summary>
                        <p className="mt-3 text-slate-600">
                            {faq.a}
                        </p>
                    </details>
                ))}
            </div>
        </div>
    );
};


export const SeoContent: React.FC = () => {
    return (
        <div className="bg-slate-50/70 py-16 sm:py-24">
            <div className="w-full max-w-5xl mx-auto px-4 space-y-20">
                <HowItWorks />
                <Features />
                <Faq />
            </div>
        </div>
    );
};