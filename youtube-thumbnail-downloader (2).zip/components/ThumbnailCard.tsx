import React from 'react';
import type { Thumbnail } from '../types';
import { ImageWithFallback } from './ImageWithFallback';
import { DownloadIcon } from './icons';

interface ThumbnailCardProps {
  thumbnail: Thumbnail;
  onDownload: () => void;
}

export const ThumbnailCard: React.FC<ThumbnailCardProps> = ({ thumbnail, onDownload }) => {
  return (
    <div className="bg-white border border-slate-200 rounded-lg shadow-md overflow-hidden transform hover:-translate-y-1 transition-all duration-300 flex flex-col">
      <div className="relative">
        <ImageWithFallback
          src={thumbnail.url}
          fallbackSrc={thumbnail.fallbackUrl}
          alt={`YouTube Thumbnail - ${thumbnail.quality}`}
        />
      </div>
      <div className="p-4 flex-grow flex flex-col">
        <h3 className="text-lg font-semibold text-slate-800">{thumbnail.quality}</h3>
        <p className="text-sm text-slate-500 mb-4">{thumbnail.resolution}</p>
        <button
          onClick={onDownload}
          className="mt-auto w-full inline-flex items-center justify-center gap-2 bg-blue-100 text-blue-700 font-semibold py-2 px-4 rounded-md hover:bg-blue-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors duration-300"
        >
          <DownloadIcon />
          Download
        </button>
      </div>
    </div>
  );
};
