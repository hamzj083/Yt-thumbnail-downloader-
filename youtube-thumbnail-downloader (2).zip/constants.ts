import React from 'react';
import type { ThumbnailQuality, ModalContent } from './types';

export const THUMBNAIL_QUALITIES: ThumbnailQuality[] = [
  { 
    id: 'maxresdefault', 
    label: 'HD Quality', 
    resolution: '1280x720 (or higher)',
    fallbackId: 'sddefault' 
  },
  { 
    id: 'sddefault', 
    label: 'High Quality', 
    resolution: '640x480 (SD)',
    fallbackId: 'hqdefault'
  },
  { 
    id: 'hqdefault', 
    label: 'Standard Quality', 
    resolution: '480x360 (HQ)' 
  },
];

const LegalNotice: React.FC = () => (
    React.createElement('p', { className: "text-xs text-slate-500 mt-4 border-t pt-2" },
        React.createElement('strong', null, 'Disclaimer:'),
        ' This is placeholder text. Consult a legal professional to draft your actual policies.'
    )
);

export const MODAL_CONTENT: { [key: string]: ModalContent } = {
  privacy: {
    title: 'Privacy Policy',
    content: (
      React.createElement('div', { className: "space-y-4 text-slate-600" },
        React.createElement('p', null, 
          'At YTThumbs, we respect your privacy. This application is designed to be a client-side tool, meaning all operations, from fetching thumbnails to creating ZIP files, happen directly in your browser.'
        ),
        React.createElement('p', null,
          'We do not collect, store, or transmit any personal data. The YouTube video URLs you enter are used solely to retrieve the publicly available thumbnail images from YouTube\'s servers. We do not use cookies for tracking and have no analytics scripts implemented. Your activity on this site is entirely private.'
        ),
        React.createElement(LegalNotice, null)
      )
    ),
  },
  terms: {
    title: 'Terms & Conditions',
    content: (
      React.createElement('div', { className: "space-y-4 text-slate-600" },
        React.createElement('p', null,
          'Welcome to YTThumbs. By using this service, you agree to these terms. This tool is provided "as is" for personal and fair use. You are responsible for ensuring you have the rights to use the downloaded thumbnails, which are the property of their respective content creators.'
        ),
        React.createElement('p', null,
          'You agree not to use this service for any illegal activities. We are not liable for any damages arising from the use of this tool. For copyright concerns or DMCA notices regarding specific thumbnails, please contact the original YouTube content creator.'
        ),
        React.createElement(LegalNotice, null)
      )
    ),
  },
  about: {
    title: 'About Us',
    content: (
      React.createElement('div', { className: "space-y-4 text-slate-600" },
        React.createElement('p', null,
          'YTThumbs was created to provide a fast, simple, and free way for content creators, marketers, and enthusiasts to download YouTube video thumbnails. We believe in building useful tools that are accessible to everyone, without the need for sign-ups or software installations.'
        ),
        React.createElement('p', null,
          'If you have any questions, feedback, or suggestions, feel free to reach out to us at: ',
          React.createElement('a', { href: "mailto:contact@ytthumbs-placeholder.com", className: "text-blue-600 hover:underline" }, 'contact@ytthumbs-placeholder.com'),
          '.'
        )
      )
    ),
  },
};
