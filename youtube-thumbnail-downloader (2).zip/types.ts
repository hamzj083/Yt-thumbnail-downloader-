import type { ReactNode } from 'react';

export interface Thumbnail {
  quality: string;
  resolution: string;
  url: string;
  fallbackUrl?: string;
}

export interface ThumbnailQuality {
  id: string;
  label: string;
  resolution: string;
  fallbackId?: string;
}

export interface ModalContent {
  title: string;
  content: ReactNode;
}
