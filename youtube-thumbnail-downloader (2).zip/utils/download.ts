import type { Thumbnail } from '../types';

// Let TypeScript know that JSZip is available globally from the CDN script
declare const JSZip: any;

const forceDownload = (blobUrl: string, filename: string) => {
  const a = document.createElement('a');
  a.href = blobUrl;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(blobUrl);
};

export const downloadFile = async (url: string, filename: string): Promise<void> => {
  try {
    const response = await fetch(url, { mode: 'cors' });
    if (!response.ok) {
        throw new Error(`Failed to fetch image: ${response.statusText}`);
    }
    const blob = await response.blob();
    const blobUrl = URL.createObjectURL(blob);
    forceDownload(blobUrl, filename);
  } catch (error) {
    console.error('Download failed:', error);
    // Fallback to opening in a new tab if CORS or other issues prevent direct download
    window.open(url, '_blank');
  }
};

export const downloadAllAsZip = async (thumbnails: Thumbnail[], zipName: string): Promise<void> => {
    try {
        const zip = new JSZip();

        const downloadPromises = thumbnails.map(thumb => 
            fetch(thumb.fallbackUrl || thumb.url, { mode: 'cors' })
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`Failed to fetch ${thumb.quality}`);
                    }
                    return response.blob();
                })
                .then(blob => {
                    zip.file(`thumbnail-${thumb.quality.toLowerCase()}.jpg`, blob);
                })
        );

        await Promise.all(downloadPromises);

        const zipBlob = await zip.generateAsync({ type: 'blob' });
        const blobUrl = URL.createObjectURL(zipBlob);
        forceDownload(blobUrl, `${zipName}.zip`);
    } catch (error) {
        console.error("Failed to create ZIP file:", error);
        alert("Could not download all files as a ZIP. Please try downloading them individually.");
    }
};
